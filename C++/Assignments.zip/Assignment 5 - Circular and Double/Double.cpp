#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>


using namespace std;


struct studentType
{
	string lastName;
	string firstName;
	float GPA;
};
struct nodeType
{
	studentType item;
	nodeType* previous;
	nodeType* next;
};
class DoublyLinkedList
{
public:
	DoublyLinkedList();
	void InsertData(studentType);
	void PrintDescending();
	void PrintAscending();
private:
	nodeType* firstptr;
	void InsertData(nodeType*&, studentType);
	void PrintAscending(nodeType*);
	void PrintDescending(nodeType*);

};
DoublyLinkedList::DoublyLinkedList()
{
	firstptr = NULL;
}
void DoublyLinkedList::InsertData(nodeType*& firstptr, studentType data)
{
	nodeType* current = new nodeType;
	current->item = data;
	current->previous = NULL;
	current->next = NULL;
	if (firstptr == NULL)
	{
		firstptr = current;
	}
	else
	{
		nodeType* curr;
		curr = firstptr;
		if (current->item.GPA<firstptr->item.GPA)
		{
			firstptr->previous = current;
			current->next = firstptr;
			firstptr = current;
			return;
		}
		if (curr->next == NULL)
		{
			if (current->item.GPA > curr->item.GPA)
			{
				current->previous = curr;
				curr->next = current;
				return;
			}
			else if (current->item.GPA < curr->item.GPA)
			{
				current->next = curr;
				curr->previous = current;
				curr = current;
				firstptr = curr;
				return;
			}
		}
		while (curr->next != NULL)
		{
			if (current->item.GPA > curr->item.GPA && current->item.GPA < curr->next->item.GPA)
			{
				current->next = curr->next;
				current->previous = curr;
				curr->next->previous = current;
				curr->next = current;
			}
			curr = curr->next;
		}
		if (current->item.GPA > curr->item.GPA)
		{
			current->previous = curr;
			curr->next = current;
		}
	}
}

void DoublyLinkedList::PrintAscending(nodeType* firstptr) {
	nodeType* curr = firstptr;
	cout << "In ascending order" << endl;
	while (curr != NULL) {
		cout << curr->item.lastName << " " << curr->item.firstName << " " << curr->item.GPA << endl;
		curr = curr->next;
	}
	cout << endl;
	return;
}
void DoublyLinkedList::PrintDescending(nodeType* firstptr) {
	nodeType* curr = firstptr;
	cout << "In descending order" << endl;
	while (curr->next != NULL) {
		curr = curr->next;
	}
	while (curr != NULL) {
		cout << " " << curr->item.lastName << " " << curr->item.firstName << " " << curr->item.GPA << endl;
		curr = curr->previous;
	}
	cout << endl;
	return;
}
void DoublyLinkedList::InsertData(studentType data) {
	InsertData(this->firstptr, data);
	return;
}
void DoublyLinkedList::PrintAscending() {
	PrintAscending(this->firstptr);
}
void DoublyLinkedList::PrintDescending() {
	PrintDescending(this->firstptr);
}
int main() {
	DoublyLinkedList studentList;
	ifstream dataFile;
	dataFile.open("infile1.txt");
	studentType item;
	while (!dataFile.eof()) {
		dataFile >> item.lastName >> item.firstName >> item.GPA;
		studentList.InsertData(item);
	}
	studentList.PrintAscending();
	studentList.PrintDescending();
	return 0;
}

/*
In ascending order
Herold, Jill 0.3
Jackson, Stan 1
Jerry, Francis 1.67
Joan, Wilson 2
Smith, Stanley 2.17
Claire, Claude 2.4
Rodriguez, San 2.89
Robinson, Mary 3.2
Elliot, Amelia 3.34
Remeaux, Sol 3.7
Bacon, Francis 4

In descending order
Bacon, Francis 4
Remeaux, Sol 3.7
Elliot, Amelia 3.34
Robinson, Mary 3.2
Rodriguez, San 2.89
Claire, Claude 2.4
Smith, Stanley 2.17
Joan, Wilson 2
Jerry, Francis 1.67
Jackson, Stan 1
Herold, Jill 0.3
*/
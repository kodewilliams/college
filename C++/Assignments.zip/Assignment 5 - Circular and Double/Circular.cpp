//#include <iostream>
//#include <fstream>
//#include <iomanip>
//#include <string>
//#include <vector>
//#include <algorithm>
//
//using namespace std;
//
//class addressType
//{
//public:
//	string streetAddressNum;
//	string streetAddress;
//	string streetType;
//	string city;
//	string state;
//	string zipCode;
//};
//
//
////define personType class
//class personType
//{
//public:
//	personType(); //constructor
//	string lastName;
//	string firstName;
//	int personNum;
//	int personID;
//	char gender;
//	addressType address;
//
//
//	string getInterest1();
//	string getInterest2();
//	void setInterest1(string);
//	void setInterest2(string);
//	void print();
//private:
//	string interest1;
//	string interest2;
//};
//
//
////personType constructor
//personType::personType()
//{
//	firstName = "";
//	lastName = "";
//	personNum = 0;
//	personID = 0;
//	gender = ' ';
//	this->address.streetAddressNum = "";
//	this->address.streetAddress = "";
//	this->address.streetType = "";
//	this->address.city = "";
//	this->address.state = "";
//	this->address.zipCode = "";
//}
//
//void personType::setInterest1(string interest)
//{
//	interest1 = interest;
//}
//
//void personType::setInterest2(string interest)
//{
//	interest2 = interest;
//}
//
//string personType::getInterest1()
//{
//	return interest1;
//}
//
//string personType::getInterest2()
//{
//	return interest2;
//}
//
//void personType::print()
//{
//	cout << lastName << " " << firstName << " " << personNum << " " << personID << " "
//		<< address.streetAddressNum << " " << address.streetAddress << " " << address.streetType << " "
//		<< address.city << " " << address.state << " " << address.zipCode << " "
//		<< gender << " " << interest1 << " " << interest2 << " ";
//}
//
//
//class DateType
//{
//
//public:
//	void Initialize(int newMonth, int newDay, int newYear);
//	void setYear(int);
//	void setMonth(int);
//	void setDay(int);
//	int GetYear() const;
//	int GetMonth() const;
//	int GetDay() const;
//private:
//	int year;
//	int month;
//	int day;
//};
//
//void DateType::Initialize(int newMonth, int newDay, int newYear) {
//	year = newYear;
//	month = newMonth;
//	day = newDay;
//}
//
//void DateType::setYear(int Yr)
//{
//	year = Yr;
//}
//void DateType::setMonth(int Month)
//{
//	month = Month;
//}
//void DateType::setDay(int Day)
//{
//	day = Day;
//}
//
//int DateType::GetYear() const
//{
//	return year;
//}
//int DateType::GetMonth() const
//{
//	return month;
//}
//int DateType::GetDay() const
//{
//	return day;
//}
//
//class monthType
//{
//public:
//	int month_num;
//	int dates[6][7];
//	monthType(); // constructor
//	void printMonth();
//	void setMonthName(string);
//	string getMonthName();
//private:
//	string month_name;
//};
//
//monthType::monthType()
//{
//	for (int row = 0; row<6; row++)
//	{
//		for (int col = 0; col<7; col++)
//			dates[row][col] = 0;
//	}
//}
//
//void monthType::setMonthName(string mon_name)
//{
//	month_name = mon_name;
//}
//
//string monthType::getMonthName()
//{
//	return month_name;
//}
//
//void monthType::printMonth()
//{
//	cout << endl << endl << month_name << endl;
//	cout << setw(6) << "Sun :" << setw(6) << "Mon :" << setw(6) << "Tue :" << setw(6) << "Wed :" << setw(6) << "Thu :" << setw(6) << "Fri :" << setw(6) << "Sat :" << endl;
//	for (int row = 0; row<6; row++)
//	{
//		for (int col = 0; col<7; col++)
//		{
//			if (dates[row][col] == 0) {
//				cout << setw(6) << "";
//			}
//			else {
//				cout << setw(6) << dates[row][col];
//			}
//
//		}
//		cout << endl; // skip a line between weeks
//	}
//}
//class yearType
//{
//public:
//	monthType months[12];
//	yearType(); //constructor
//	void printYear()
//	{
//		for (int month_index = 0; month_index<12; month_index++)
//		{
//			months[month_index].printMonth();
//		}
//	}
//};
//yearType::yearType()
//{
//	for (int i = 0; i<12; i++)
//		months[i].month_num = i;
//}
//class calendar
//{
//public:
//	void printCalendar();
//};
//
//int get_year();
//int get_starting_day();
//void print_heading(int);
//string read_month_name(ifstream&);
//int read_num_days(ifstream&);
//int print_month(int, int, string, int); //function
//
//yearType thisYear;
//
//
//int get_year()
//{
//	/*prompt user to enter year*/
//	int year;
//	cout << "Enter the year : ";
//	cin >> year;
//	return year;
//}
//int get_starting_day()
//{
//	/*The day of the week for the first day of the year (January 1st)
//	is entered by the user during the execution of the get_starting_date function*/
//	int start_day;
//	cout << "Enter the start date (0 = Sun, 1 = Mon, 2 = Tues, 3 = Wed, 4 = Thurs, 5 = Fri, 6 = Sat) : ";
//	cin >> start_day;
//	return start_day;
//}
//void print_heading(int year)
//{
//	cout << " YEAR -- " << year << endl; //print year at the top of the calendar
//}
//string read_month_name(ifstream& myfile) //using referencing to read from myfile which was opened in main
//{
//	string month_name;
//	myfile >> month_name; //read month name from input file
//	return month_name;
//}
//int read_num_days(ifstream& myfile) //using referencing to read from myfile which was opened in main
//{
//	int num_days;
//	myfile >> num_days; //read num of days from input file
//	return num_days;
//}
//int print_month(int first_day, int num_of_days,
//	string month_name, int mon_num) //returns the LAST DAY OF THE MONTH
//{
//	cout << endl << endl << month_name << endl;
//	cout << setw(6) << "Sun :" << setw(6) << "Mon :" << setw(6) << "Tue :" << setw(6) << "Wed :" << setw(6) << "Thu :" << setw(6) << "Fri :" << setw(6) << "Sat :" << endl;
//	int days; //keeps tracks of integers to print for days
//	days = 0;
//	int wk = 0;
//	int day_of_week;
//	day_of_week = first_day; //will keep track of which day of the week is being printed
//	int day_count;
//	day_count = 0; // keeps track of the placement of the first day of each month
//	while (day_count < first_day) //if the day count is anything but 0 the number of tabs equal to the first day will be printed
//	{
//		cout << setw(6) << "";
//		day_count++;
//	}
//	while (days < num_of_days) //will only print integers less than or equal to the max number of days of that month
//	{
//		days++;
//		cout << setw(6) << days;
//		thisYear.months[mon_num].dates[wk][day_of_week] = days;
//		day_of_week++;
//		if (day_of_week > 6) //if saturday integer is printed then the line should end the and the next integer will be printed under sunday
//		{
//			cout << endl;
//			day_of_week = 0;
//			wk++;
//		}
//		if (wk > 5)
//		{
//			wk = 0;
//		}
//	}
//	return day_of_week;
//}
//
//
//class USDollarCents
//{
//private:
//	double dollars;
//	double cents;
//
//	// ****** USDollarCents Normalize ******
//	void normalize();
//
//
//public:
//	USDollarCents(double dollars = 0, double cents = 0);
//	USDollarCents Length(void) const; // USDollarCents length
//	void CopyUSDollarCents(USDollarCents* t) const; // copy USDollarCents 
//
//													// Write USDollarCents
//	friend ostream& operator<< (ostream& ostr, const USDollarCents& s);
//	// Read USDollarCentss
//	friend istream& operator >> (istream& istr, USDollarCents& s);
//
//	// ***** relational operator *****
//
//	// USDollarCents == USDollarCents 
//	double operator== (const USDollarCents& s) const;
//	// USDollarCents < USDollarCents 
//	double operator< (const USDollarCents& s) const;
//	// USDollarCents > USDollarCents 
//	double operator> (const USDollarCents& s) const;
//	// USDollarCents <= USDollarCents 
//	double operator<= (const USDollarCents& s) const;
//	// USDollarCents >= USDollarCents 
//	double operator>= (const USDollarCents& s) const;
//	// USDollarCents != USDollarCents 
//	double operator!= (const USDollarCents& s) const;
//
//	// ***** USDollarCents Arithmetic operators ****
//
//	// ***** USDollarCents addition *****
//	USDollarCents operator+ (const USDollarCents& s) const;
//
//	// ***** USDollarCents addition equal *****
//	void operator+= (const USDollarCents& s);
//
//	// ***** USDollarCents subtraction *****
//	USDollarCents operator- (const USDollarCents& s) const;
//
//	// ***** USDollarCents subtraction equal *****
//	void operator-= (const USDollarCents& s);
//
//	// ***** USDollarCents mutiplication *****
//	USDollarCents operator* (double) const;
//
//	// ***** USDollarCents mutiplication equal *****
//	void operator*= (double);
//
//	// ***** USDollarCents division *****
//	USDollarCents operator/ (double) const;
//
//	// *******  USDollarCents absolute value ***
//	USDollarCents absolute() const;
//
//	// ******* USDollarCents divided by 100 ***
//	USDollarCents divideby100() const;
//
//	double getDollars();
//	double getCents();
//};
//
/////**********************************************************
////      CLASS USDollarCents IMPLEMENTATION 
////**********************************************************
//
//USDollarCents::USDollarCents(double dd, double cc) : dollars(dd), cents(cc)
//{
//	while (cents >= 100)
//	{
//		cents = cents - 100;
//		dollars++;
//	}
//}
//
//double USDollarCents::getDollars()
//{
//	return dollars;
//}
//
//double USDollarCents::getCents()
//{
//	return cents;
//}
//
//ostream& operator<< (ostream& ostr, const USDollarCents& s)
//{
//	ostr << "$" << s.dollars << "." << s.cents;
//	return ostr;
//}
//
//istream& operator >> (istream& istr, USDollarCents& s)
//{
//	char char1;
//	istr >> s.dollars >> char1 >> s.cents;
//	return istr;
//}
//
//double USDollarCents::operator< (const USDollarCents& s) const
//{
//	if (dollars < s.dollars)
//		return 1;
//	else
//		if (dollars == s.dollars)
//			if (cents < s.cents)
//				return 1;
//			else
//				return 0;
//		else
//			return 0;
//}
//double USDollarCents::operator> (const USDollarCents& s) const
//{
//	if (dollars > s.dollars)
//		return 1;
//	else
//		if (dollars == s.dollars)
//			if (cents > s.cents)
//				return 1;
//			else
//				return 0;
//		else
//			return 0;
//}
//
//double USDollarCents::operator== (const USDollarCents& s) const
//{
//	if ((dollars == s.dollars) && (cents == s.cents))
//		return 1;
//	else
//		return 0;
//}
//
//USDollarCents USDollarCents::operator+ (const USDollarCents& s) const
//{
//	double h = dollars + s.dollars;
//	double m = cents + s.cents;
//	USDollarCents D(h, m);
//	D.normalize();
//	return D;
//}
//
//void USDollarCents::operator+= (const USDollarCents& s)
//{
//	dollars += s.dollars;
//	cents += s.cents;
//	if (cents >= 100)
//	{
//		cents = cents - 100;
//		dollars++;
//	}
//	normalize();
//}
//
//
//USDollarCents USDollarCents::operator- (const USDollarCents& s) const
//{
//	double h = dollars - s.dollars;
//	double m = cents - s.cents;
//	if (m < 0)
//	{
//		m = m + 100;
//		h--;
//	}
//	USDollarCents D(h, m);
//	D.normalize();
//	return D;
//}
//
//void USDollarCents::operator-= (const USDollarCents& s)
//{
//	dollars -= s.dollars;
//	cents -= s.cents;
//	if (cents < 0)
//	{
//		cents = cents + 100;
//		dollars--;
//	}
//	normalize();
//}
//
//USDollarCents USDollarCents::operator* (double x) const
//{
//	double h = dollars * x;
//	double m = cents * x;
//	if (m < 0)
//	{
//		m = m + 100;
//		h--;
//	}
//	USDollarCents D(h, m);
//	D.normalize();
//	return D;
//}
//
//void USDollarCents::operator*= (double x)
//{
//	dollars *= x;
//	cents *= x;
//	while (cents >= 100)
//	{
//		cents = cents - 100;
//		dollars++;
//	}
//	normalize();
//}
//
//USDollarCents USDollarCents::absolute() const
//{
//	double h = abs(dollars);
//	double m = abs(cents);
//	USDollarCents D(h, m);
//	return D;
//}
//
//USDollarCents USDollarCents::divideby100() const
//{
//	double m = cents;
//	double h = dollars;
//
//	m = h * 100 + m;
//	h = m / 10000;
//	m = ((m / 10000.0) - h + .005) * 100;
//
//	USDollarCents D(h, m);
//	D.normalize();
//	return D;
//}
//
//void  USDollarCents::normalize()
//{
//	if ((dollars != 0) && (cents != 0))
//	{
//		if ((dollars < 0) && (cents > 0))
//		{
//			if (cents > 0)
//			{
//				cents = cents - 100;
//				dollars++;
//			}
//		}
//
//		if ((dollars > 0) && (cents < 0))
//		{
//			if (cents < 0)
//			{
//				cents = cents + 100;
//				dollars--;
//			}
//		}
//	}
//}
//
//
//USDollarCents Compute_Service_Charge(char, USDollarCents, USDollarCents);// function prototypes
//USDollarCents Compute_Interest(char, USDollarCents, USDollarCents);
//void Print_Line(char, double, USDollarCents);
//
////If a customer's balance falls below the minimum balance, there is a service charge of $10.00 for savings accounts and $25.00 for checking accounts.
//USDollarCents Compute_Service_Charge(char acc_type, USDollarCents min_bal, USDollarCents acc_bal) // function header
//{
//	if ((acc_type == 'S') && (acc_bal < min_bal)) // if condition
//		return 10.00;
//	else
//		if ((acc_type == 'C') && (acc_bal < min_bal)) // if condition
//			return 25.00;
//		else // this else goes with the first if statement
//			return 0;
//}
////If the balance at the end of the month is at least the minimum balance, the account receives interest as follows
////a. Savings accounts receive 4% interest.
////b. Checking accounts with balances of up to $5,000 more than the minimum balance receive 3% interest; otherwise, the interest is 5%.
//USDollarCents Compute_Interest(char acc_type, USDollarCents min_bal, USDollarCents acc_bal) // funciton header
//{
//	if ((acc_type == 'S') && (acc_bal > min_bal)) // if condition
//		return USDollarCents(acc_bal * .04); // return interest
//	else
//	{
//		if ((acc_type == 'C') && (acc_bal > min_bal)) // else if condition
//		{
//			if (acc_bal < (min_bal + 5000.00)) // nested if condition
//				return USDollarCents(acc_bal * .03); // return interest
//			else
//				return USDollarCents(acc_bal * .05); // return interest
//		}
//		else
//			return 0;
//	}
//}
//void Print_Line(char acc_type, double acc_num, USDollarCents acc_bal) // funciton header
//{
//	string account_type; // variable declaration
//	if (acc_type == 'S') // if condition
//		account_type = "Savings"; // variable assignment
//	else
//		account_type = "Checking"; // variable assignment
//	cout << "************************************" << endl; // output header
//	cout << "\tBank Account Report" << endl << endl; // output header
//	cout << "Account Number:" << setw(9) << right << acc_num << endl << endl; // output info
//	cout << "Account Type:" << setw(12) << right << account_type << endl << endl; // output info
//	cout << "Account Balance: $" << setw(6) << right << setprecision(2) << acc_bal << endl << endl; // output info
//}
//
//
//
////define membershipType class
//class membershipType :public personType
//{
//public:
//	char membership_type;
//	char membership_status;
//	yearType memberCalendar;
//	USDollarCents memberAccount;
//	membershipType();  // 1st constructor
//	membershipType(char, char);  // 2nd constructor
//	void print_member_type();
//	bool operator<(const membershipType &rhs) const
//	{
//		return personID < rhs.personID;
//	}
//};
//
//
////membershipType constructor
//membershipType::membershipType()
//{
//	membership_type = ' ';
//	membership_status = ' ';
//}
//
//
//membershipType::membershipType(char type, char status)
//{
//	membership_type = type;
//	membership_status = status;
//}
//
//void membershipType::print_member_type()
//{
//	print();
//	cout << membership_type << " " << membership_status << endl;
//}
//
//#define MAX 6
//int num = 0;
//
//struct node
//{
//	membershipType info;
//	node *next;
//};
//
//class QueueType
//{
//public:
//	QueueType();
//	void makeEmpty();
//	bool isEmpty() const;
//	bool isFull() const;
//	void enqueue(membershipType);
//	void dequeue(membershipType&);
//private:
//	node *rear;
//	node *front;
//};
//
//QueueType::QueueType()
//{
//	rear = NULL;
//	front = NULL;
//}
//
//void QueueType::makeEmpty()
//{
//	front = NULL;
//	rear = NULL;
//}
//
//void QueueType::enqueue(membershipType m)
//{
//	node *current = new node;
//
//	if (!isFull()) {
//		current->info.firstName = m.firstName;
//		current->info.lastName = m.lastName;
//		current->info.personNum = m.personNum;
//		current->info.personID = m.personID;
//		current->info.address.streetAddressNum = m.address.streetAddressNum;
//		current->info.address.streetAddress = m.address.streetAddress;
//		current->info.address.streetType = m.address.streetType;
//		current->info.address.city = m.address.city;
//		current->info.address.state = m.address.state;
//		current->info.address.zipCode = m.address.zipCode;
//		current->info.gender = m.gender;
//		current->info.setInterest1(m.getInterest1());
//		current->info.setInterest2(m.getInterest2());
//		current->info.memberAccount = m.memberAccount;
//
//		current->next = front;
//
//		if (front == NULL)
//			front = current;
//		else {
//			rear->next = current;
//		}
//
//		rear = current;
//		num++;
//	}
//	else {
//		cout << "Queue is full." << endl;
//	}
//}
//
//
//void QueueType::dequeue(membershipType& m) {
//
//	node *temp = new node;
//
//	if (front == NULL)
//		cout << "\nQueue is Emtpty\n";
//	else
//	{
//		temp = front;
//
//		m.firstName = temp->info.firstName;
//		m.lastName = temp->info.lastName;
//		m.personNum = temp->info.personNum;
//		m.personID = temp->info.personID;
//		m.address.streetAddressNum = temp->info.address.streetAddressNum;
//		m.address.streetAddress = temp->info.address.streetAddress;
//		m.address.streetType = temp->info.address.streetType;
//		m.address.city = temp->info.address.city;
//		m.address.state = temp->info.address.state;
//		m.address.zipCode = temp->info.address.zipCode;
//		m.gender = temp->info.gender;
//		m.setInterest1(temp->info.getInterest1());
//		m.setInterest2(temp->info.getInterest2());
//		m.memberAccount = temp->info.memberAccount;
//
//		front = front->next;
//		delete temp;
//	}
//
//	num--;
//
//
//}
//
//
//bool QueueType::isEmpty() const
//{
//	return (front == NULL && rear == NULL);
//}
//
//bool QueueType::isFull() const
//{
//	node *current;
//
//	if (front == NULL || rear == NULL)
//		return false;
//	else
//		return (num >= MAX);
//}
//
//
//int main()
//{
//	ifstream dataFile;
//	QueueType memberList;
//	membershipType current;
//	string interest1, interest2;
//	double dd, cc;
//
//	dataFile.open("infile.txt");
//
//	for (int i = 0; i < 6; i++)
//	{
//		dataFile >> current.lastName
//			>> current.firstName
//			>> current.personNum
//			>> current.personID
//			>> current.address.streetAddressNum
//			>> current.address.streetAddress
//			>> current.address.streetType
//			>> current.address.city
//			>> current.address.state
//			>> current.address.zipCode
//			>> current.gender
//			>> interest1 >> interest2
//			>> current.membership_type
//			>> current.membership_status
//			>> dd >> cc;
//
//		current.memberAccount = USDollarCents(dd, cc);
//		current.setInterest1(interest1);
//		current.setInterest2(interest2);
//		memberList.enqueue(current);
//	}
//
//	do
//	{
//		memberList.dequeue(current);
//		cout << current.lastName << " "
//			<< current.firstName << " "
//			<< current.personNum << " "
//			<< current.personID << " "
//			<< current.address.streetAddressNum << " "
//			<< current.address.streetAddress << " "
//			<< current.address.streetType << " "
//			<< current.address.city << " "
//			<< current.address.state << " "
//			<< current.address.zipCode << " "
//			<< current.gender << " "
//			<< current.getInterest1() << " "
//			<< current.getInterest2() << " "
//			<< current.membership_type << " "
//			<< current.membership_status << " "
//			<< current.memberAccount.getDollars() << " "
//			<< current.memberAccount.getCents() << endl;
//	} while (num > 0);
//
//
//	system("pause");
//	return 0;
//}
//
///*
//Output
//
//Herold, Jill 1 2234 123 Main St. Washington, DC 20019 F yoga facebook 1 1 231 12
//Jackson, Stan 2 3748 12 Douglas Ave. Baltimore, MD 30229 M sports movies 1 1 200 0
//Jerry, Francis 3 6666 2345 6th Street Woodbridge, VA 44040 M movies roadtrips 1 1 611 33
//Joan, Wilson 4 1234 12 Georgia Ave. Washington, DC 20019 F romance dining 1 1 190 10
//Smith, Stanley 5 3456 56 D Street Baltimore, MD 30229 M movies dining 1 1 876 25
//Claire, Claude 6 2311 66 32nd Street Woodbridge, VA 44040 F cooking facebook 1 1 332 99
//
//
//*/
#include <iostream>
#include <fstream>
#include <string>

using namespace std;


class personType
{
public:
	string first_name;
	string last_name;
	int team_code;
	string home_city;
};

struct nodeType
{
	personType info;
	nodeType* next;
};

template <class T>
class sortedListType
{
public:
	sortedListType() {
		length = 0;
		head = NULL;
	}

	~sortedListType();

	void insertinOrder(T const&);
	nodeType* head;
	int length;
};

template <class T>
sortedListType<T>::~sortedListType()
{
	/*nodeType* curr;
	
	while (head != NULL)
	{
		curr = head;
		head = head->next;
		delete curr;
	}*/
}


template <class T>
void sortedListType<T>::insertinOrder(T const& elem)
{
	nodeType* temp = new nodeType;
	nodeType* current;
	nodeType* previous;

	temp->info = elem;
	temp->next = NULL;

	if (head == NULL) {
		head = temp;
		length++;
		return;
	}
	else if (temp->info.last_name < head->info.last_name)
	{
		temp->next = head;
		head = temp;
		length++;
		return;
	}
	else {
		current = head;
		previous = head;

		while (current)
		{
			if (temp->info.last_name < current->info.last_name)
			{
				previous->next = temp;
				temp->next = current;
				length++;
				return;
			}
			previous = current;
			current = current->next;
		}
	}
	previous->next = temp;
	length++;
}

template <class T>
void print(sortedListType<T>);

int main()
{
	sortedListType<personType> personList;
	personType temp;
	ifstream dataFile;

	dataFile.open("infile.txt");
	
	while (!dataFile.eof())
	{
		dataFile >> temp.first_name
			>> temp.last_name
			>> temp.team_code
			>> temp.home_city;
		personList.insertinOrder(temp);
	}

	print(personList);

	system("pause");
	return 0;
}

template <class T>
void print(sortedListType<T> personList)
{
	nodeType* current;
	
	current = personList.head;
	while (current)
	{
		cout << current->info.first_name << " "
			<< current->info.last_name << " "
			<< current->info.team_code << " "
			<< current->info.home_city << endl;
		current = current->next;
	}
}


/*
Output

Adegboyega Akinsiku 4 Topeka
Susan Angus 3 Burke
Jonnetta Bratcher 3 Charleston
Charles Brown 0 Bowie
Alyssa Bullock 6 Baltimore
Kerisha Burke 7 Washington
Allee Clark 4 Pittsburg
Cherith-Eden Clements 5 Hagerstown
Isa Edwards-El 3 Greensburg
Terrance Ellis 6 Columbia
Dhuel Fisher 8 Richmord
Victor Foreman 4 Earlsville
Jaleesa Harrigan 1 Harrisonburg
Remington Holt 2 Detriot
Brionna Huskey 1 Sacramento
Brittany Jackson 5 Denver
Matthew Jacobs 8 Nashville
Kendall Keeling 3 Miami
Kourtnei Langley 9 Louisville
Johan Lingani 8 Woodbridge
Crepin Mahop 2 Bolder
Blanche Mahop 6 Austin
Ashlee McKinney 3 Houston
Jennifer Ojie 7 Arlington
Kareem Parris-Baptiste 8 Princeton
Joanna Phillip 1 Tampa
Michael Phillips 3 Boston
Rashad Rose 7 Fredricksburg
Candace Ross 0 Rockville
Saboor Salaam 1 Reston
Ranjay Salmon 2 Trenton
Theodore Santos-Gaffney 9 Towson
Aja Walton 3 Boise
Kyle Ward 5 Germantown
Illium Williams 8 Juray
Malcolm Williams 2 Winchester
Press any key to continue . . .
*/
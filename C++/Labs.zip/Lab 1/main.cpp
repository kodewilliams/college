#include <iostream>

using namespace std;

class arithmetic
{
protected: 

public:
	void getData(int *a, int *b)
	{
		cout << "\nEnter the first number: ";
		cin >> *a;
		cout << "Enter the second number: ";
		cin >> *b;
	}
};

class plus_ :public virtual arithmetic
{
protected:
	int num1, num2, sum;
public:
	void add()
	{
		cout << "For Addition:";
		getData(&num1, &num2);
		sum = num1 + num2;
	}
};

class minus_ :public virtual arithmetic
{
protected:
	int n1, n2, diff;
public:
	void sub()
	{
		cout << "\nFor Subtraction:";
		getData(&n1, &n2);
		diff = n1 - n2;
	}
};

class result :public virtual plus_, public virtual minus_
{
public:
	void display()
	{
		cout << "\nSum of " << num1 << " and " << num2 << " = " << sum << endl;
		cout << "Difference of " << n1 << " and " << n2 << " = " << diff << endl;
	}
};

void main()
{
	result z;

	z.add();
	z.sub();
	z.display();
	system("pause");
}

/*

Output of Program
----------------------------

For Addition:
Enter the first number: 4
Enter the second number: 5

For Subtraction:
Enter the first number: 6
Enter the second number: 7

Sum of 4 and 5 = 9
Difference of 6 and 7 = -1

*/
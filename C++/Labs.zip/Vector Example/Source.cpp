#include <iostream>
#include <vector>
using namespace std;

int main()
{
	vector<double> student_marks;
	int number;
	char answer;
	cout << "Do you want to enter numbers (y/n)? ";
	cin >> answer;
	while (answer == 'y') {
		cout << "Enter value: ";
		cin >> number;
		// Now that we have the number from the user, append it at the end of the vector
		student_marks.push_back(number);
		cout << "Do you want to enter more numbers (y/n)? ";
		cin >> answer;
	}

	/* Now print all the values.
	Notice that we didn't need to count how many elements were entered:� we can always use
	the size() method to ask student_marks how many are there!  */

	for (int i = 0; i < student_marks.size(); i++)
	{
		cout << "Student #" << i + 1 << '\t' << student_marks[i] << endl;
	}
	return 0;
}



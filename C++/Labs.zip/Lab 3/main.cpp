#include <iostream>
#include <string>

using namespace std;

class person
{
protected:
	string firstName;
	string lastName;

public:
	void setName()
	{
		cout << "First Name: ";
		cin >> firstName;
		cout << "Last Name: ";
		cin >> lastName;

	}
};

class student : public virtual person
{
protected:
	string level;
	string major;
	string hometown;

public:
	void getStudentDetails()
	{
		cout << "Classification: ";
		cin >> level;
		cout << "Major: ";
		cin >> major;
		cout << "Hometown: ";
		cin >> hometown;
	}
};

class teacher : public virtual person
{
protected:
	string course;
	string fName;
	string lName;

public:
	void getTeacherDetails()
	{
		cout << "\nTeacher First Name: ";
		cin >> fName;
		cout << "Teacher Last Name: ";
		cin >> lName;
		cout << "Course Name: ";
		cin >> course;
	}

};

class classroom : public virtual student, public virtual teacher
{
public:
	void intro()
	{
		cout << "\n\n";
		cout << "Student: Hello my name is " << firstName << " " << lastName << " and I'm a " << level << " majoring in " << major << ", from " << hometown << "." << endl;
		cout << "Teacher: Hi, I am " << fName << " " << lName << " and I will be guiding you through the " << course << " course this semester." << endl;
		system("pause");
	}
};



int main()
{
	classroom c;

	c.setName();
	c.getStudentDetails();
	c.getTeacherDetails();
	c.intro();

	return 0;
}

/*

Output of Program
----------------------------

First Name: Kode
Last Name: Williams
Classification: Freshman
Major: CS
Hometown: Kingston

Teacher First Name: Harry
Teacher Last Name: Keeling
Course Name: CSII


Student: Hello my name is Kode Williams and I'm a Freshman majoring in CS, from Kingston.
Teacher: Hi, I am Harry Keeling and I will be guiding you through the CSII course this semester.

*/
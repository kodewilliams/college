//#include <iostream>
//#include <string>
//
//using namespace std;
//
//template<typename T>
//
//void display(T arr[], int size)
//{
//	for (int i = 0; i < size; ++i)
//	{
//		cout << arr[i] << " ";
//	}
//
//	cout << endl;
//}
//
//int main()
//{
//	const int size = 10;
//
//	string names[] = { "Nate", "Robert", "Tahj", "Amara", "Monique", "Tim", "Shumba", "Kode", "Ashley", "Jachin" };
//
//	display(names, size);
//
//	system("pause");
//	return 0;
//}
//
///*
//Output
//
//Nate Robert Tahj Amara Monique Tim Shumba Kode Ashley Jachin
//Press any key to continue . . .
//
//*/
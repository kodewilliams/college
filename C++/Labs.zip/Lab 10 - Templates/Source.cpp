//#include <iostream>
//#include <string>
//
//using namespace std;
//
//template<typename T>
//
//void display(T arr[], int size)
//{
//	for (int i = 0; i < size; ++i)
//	{
//		cout << arr[i] << " ";
//	}
//
//	cout << endl;
//}
//
//int main()
//{
//	const int size = 10;
//
//	int numbers[size];
//
//	for (int i = 0; i < size; ++i)
//		numbers[i] = i + 1;
//
//	display(numbers, size);
//
//	system("pause");
//	return 0;
//}
//
//
//
///*
//Output
//
//1 2 3 4 5 6 7 8 9 10
//*/

//#include <iostream>
//#include <string>
//
//using namespace std;
//
//template<typename T>
//
//T max(T &arg1, T &arg2)
//{
//	if (arg1 > arg2)
//	{
//		return arg1;
//	}
//	else
//	{
//		return arg2;
//	}
//}
//
//int main()
//{
//	int a = 18;
//	int b = 9;
//	cout << max(a, b) << endl;
//
//	double x = 3.14;
//	double y = 1.69;
//	cout << max(x, y) << endl;
//
//	string w1 = "burger";
//	string w2 = "fries";
//	cout << max(w1, w2) << endl;
//
//	system("pause");
//	return 0;
//}
//
//
///*
//Output
//
//18
//3.14
//fries
//Press any key to continue . . .
//
//*/
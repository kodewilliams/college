#include <iostream>
using namespace std;

class Line
{
public:
	int getLength();
	Line(int len);
	Line(const Line &obj);
		~Line();
private:
	int *ptr;
};

// Member functions definitions including constructor
Line::Line(int len)
{
	cout << "Normal constructor allocating ptr" << endl;
	ptr = new int;
	*ptr = len;
}

Line::Line(const Line &obj)
{
	cout << "Copy constructor allocating ptr." << endl;
	ptr = new int;
	*ptr = *obj.ptr;
}

Line::~Line()
{
	cout << "Freeing memory!" << endl;
	delete ptr;
}

int Line::getLength()
{
	return *ptr;
}

void display(Line obj)
{
	cout << "Length of line: " << obj.getLength() << endl;
}

int main()
{
	Line line1(10);
	display(line1);
	system("pause");
	return 0;
}
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct personType
{
	string firstName;
	string lastName;
	int num;
	string location;
};

struct nodeType
{
	personType info;
	nodeType* previous;
	nodeType* next;
};

class sortedListType
{
public:
	sortedListType()
	{
		length = 0;
		head = NULL;
	}
	void insert(personType const&);
	personType getItem(string);
	nodeType* goToNode(nodeType*, int, char);
	void print();

	
private:
	int length;
	nodeType* head;
};

nodeType* sortedListType::goToNode(nodeType* current, int moves, char direction)
{
	for (int i = 0; i < moves; i++)
	{
		if (direction == 'B')
			current = current->previous;
		else
			current = current->next;
	}

	return current;
}

personType sortedListType::getItem(string check)
{
	int left = 0;
	int right = length - 1;
	char dir = 'F';
	nodeType* current = head;
	personType emptyPerson;

	while (left <= right) {
		int middle = (left + right) / 2;
		current = goToNode(current, middle - left, dir);
		if (current->info.lastName == check)
			return current->info;
		else if (current->info.lastName > check)
		{
			right = middle - 1;
			dir = 'B';
		}
		else
		{
			left = middle + 1;
		}
	}

	emptyPerson.firstName = "";
	emptyPerson.lastName = "";
	emptyPerson.num = 0;
	emptyPerson.location = "";
	return emptyPerson;

}

void sortedListType::insert(personType const& p)
{
	nodeType* temp = new nodeType;
	nodeType* current;
	nodeType* previous;

	temp->info = p;
	temp->next = NULL;
	temp->previous = NULL;

	if (head == NULL) {
		head = temp;
		length++;
		return;
	}
	else {
		current = head;
		previous = head;

		while (current)
		{
			previous = current;
			current = current->next;
		}
	}
	previous->next = temp;
	previous->previous = previous;
	length++;
}

void sortedListType::print()
{
	nodeType* current;

	current = head;
	for (int i = 0; i < length; i++)
	{
		cout << current->info.firstName << " "
			<< current->info.lastName << " "
			<< current->info.num << " "
			<< current->info.location << endl;
		current = current->next;
	}
}

int main()
{
	sortedListType persons;
	personType temp;
	ifstream data;
	char choice = 'Y';
	string searchval;

	data.open("infile.txt");

	for (int i = 0; i < 36; i++)
	{
		data >> temp.firstName >> temp.lastName
			>> temp.num >> temp.location;
		persons.insert(temp);
	}

	//persons.print();

	while (choice != 'N')
	{
		cout << "Last name to search for: ";
		cin >> searchval;
		temp = persons.getItem(searchval);
		cout << endl << temp.firstName << " "
			<< temp.lastName << " "
			<< temp.num << " "
			<< temp.location << endl;

		cout << endl << "Search again? [Y/N] : ";
		cin >> choice;
	}

	system("pause");
	return 0;
}


/*
Output

Last name to search for: Salmon

Ranjay Salmon 2 Trenton

Search again? [Y/N] : N
Press any key to continue . . .

*/
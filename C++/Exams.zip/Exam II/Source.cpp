#include <iostream>
#include <fstream>
#include <string>

using namespace std;


class personType
{
public:
	string first_name;
	string last_name;
	string telephone;
};

struct nodeType
{
	personType info;
	nodeType* next;
};


class sortedListType
{
public:
	sortedListType() {
		length = 0;
		head = NULL;
	}

	void insertinOrder(personType const&);
	nodeType* head;
	int length;
};


void sortedListType::insertinOrder(personType const& item)
{
	nodeType* temp = new nodeType;
	nodeType* current;
	nodeType* previous;

	temp->info = item;
	temp->next = NULL;

	if (head == NULL) {
		head = temp;
		length++;
		return;
	}
	else if (temp->info.last_name < head->info.last_name)
	{
		temp->next = head;
		head = temp;
		length++;
		return;
	}
	else {
		current = head;
		previous = head;

		while (current)
		{
			if (temp->info.last_name < current->info.last_name)
			{
				previous->next = temp;
				temp->next = current;
				length++;
				return;
			}
			previous = current;
			current = current->next;
		}
	}
	previous->next = temp;
	length++;
}


void print(sortedListType);

int main()
{
	sortedListType personList1, personList2, mergedList;
	personType temp;
	ifstream dataFile;

	dataFile.open("infile.txt");

	for (int i=0; i<7; i++)
	{
		dataFile >> temp.first_name
			>> temp.last_name
			>> temp.telephone;
		personList1.insertinOrder(temp);
		mergedList.insertinOrder(temp);
	}
	for (int i = 0; i<7; i++)
	{
		dataFile >> temp.first_name
			>> temp.last_name
			>> temp.telephone;
		personList2.insertinOrder(temp);
		mergedList.insertinOrder(temp);
	}


	print(personList1);
	cout << endl;
	print(personList2);
	cout << endl << endl;
	print(mergedList);

	system("pause");
	return 0;
}


void print(sortedListType personList)
{
	nodeType* current;

	current = personList.head;
	while (current)
	{
		cout << current->info.first_name << " "
			<< current->info.last_name << " "
			<< current->info.telephone << endl;
		current = current->next;
	}
}


/*
Output

Adegboyega Akinsiku (202)234-5678
Jonnetta Bratcher (345)444-6738
Dhuel Fisher (410)7878-5503
Remington Holt (310)567-2349
Kendall Keeling (202)694-0090
Joanna Phillip (304)550-1236
Ranjay Salmon (410)555-6666

Charles Brown (201)345-223-0021
Kerisha Burke (310)445-2939
Allee Clark (410)778-3848
Brionna Huskey (921)858-2348
Brittany Jackson (410)120-4502
Kourtnei Langley (202)880-6729
Michael Phillips (404)567-2345


Adegboyega Akinsiku (202)234-5678
Jonnetta Bratcher (345)444-6738
Charles Brown (201)345-223-0021
Kerisha Burke (310)445-2939
Allee Clark (410)778-3848
Dhuel Fisher (410)7878-5503
Remington Holt (310)567-2349
Brionna Huskey (921)858-2348
Brittany Jackson (410)120-4502
Kendall Keeling (202)694-0090
Kourtnei Langley (202)880-6729
Joanna Phillip (304)550-1236
Michael Phillips (404)567-2345
Ranjay Salmon (410)555-6666
Press any key to continue . . .
*/
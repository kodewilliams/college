#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class flightType
{
public:
	string fromCity;
	string toCity;
};

class econoflightType : public flightType
{
public:
	float discountPrice;
	int maxPassengers;
	int currentPassengers;
	econoflightType();
};

struct nodeType
{
	econoflightType info;
	nodeType* next;
};

econoflightType::econoflightType()
{
	fromCity = "";
	toCity = "";
	maxPassengers = 0;
	currentPassengers = 0;
	discountPrice = 0.0;
}

void getFlightData(nodeType*& flightListptr, ifstream& dataFile);
void addEnd(nodeType flightNode, nodeType*& flightListptr);
void bookPassengers(nodeType* flightListptr, int no_of_Passengers, int flightNo);
void printBookingReport(nodeType* flightListptr);

int main()
{
	nodeType* flightListptr;
	ifstream dataFile;
	int flightNo;
	int no_of_Passengers;

	dataFile.open("infile.txt");
	getFlightData(flightListptr, dataFile);

	do
	{
		cout << endl << "Flight No: ";
		cin >> flightNo;
		cout << "No of Passengers: ";
		cin >> no_of_Passengers;
		bookPassengers(flightListptr, no_of_Passengers, flightNo);
	} while ((flightNo != 0) && (no_of_Passengers != 0));

	printBookingReport(flightListptr);

	return 0;
}
void getFlightData(nodeType*& flightListptr, ifstream& dataFile)
{
	nodeType flightNode;
	for (int i = 0; i < 10; i++)
	{
		dataFile >> flightNode.info.fromCity;
		dataFile >> flightNode.info.toCity;
		dataFile >> flightNode.info.maxPassengers;
		dataFile >> flightNode.info.currentPassengers;
		dataFile >> flightNode.info.discountPrice;
		addEnd(flightNode, flightListptr);
	}
}
void addEnd(nodeType flightNode, nodeType*& flightListptr)
{
	if (flightListptr = NULL)
	{
		flightListptr->info = flightNode.info;
		flightListptr->next = new nodeType;
	}
	else
	{
		nodeType* currentNode;
		for (currentNode = flightListptr->next; currentNode != NULL; currentNode = flightListptr->next);
		currentNode->info = flightNode.info;
		currentNode->next = NULL;
	}
	

}
void bookPassengers(nodeType* flightListptr, int no_of_Passengers,
	int flightNo)
{

}
void printBookingReport(nodeType* flightListptr)
{
	cout << fixed << showpoint;
	cout << "\n     From          To             Max       Current          Price\n\n";
	for (int x = 0; x < 10; x++)
	{
		cout << setw(12) << flightListptr->info.fromCity
			<< setw(12) << flightListptr->info.toCity
			<< setw(12) << flightListptr->info.maxPassengers
			<< setw(12) << flightListptr->info.currentPassengers
			<< setw(12) << setprecision(2) << "$" <<
			flightListptr->info.discountPrice << endl;
		flightListptr = flightListptr->next;
	}
}
#include <iostream>
#include <string>

using namespace std;

template<typename ItemType>
void Swap(ItemType& V1, ItemType& V2)
{
	ItemType temp;
	temp = V1;
	V1 = V2;
	V2 = temp;
}

template<typename ItemType>
void BubbleUp(ItemType values[],
	int startIndex, int endIndex)
	// Post: Adjacent pairs that are out of 
	//   order have been switched between 
	//   values[startIndex]..values[endIndex]  
	//   beginning at values[endIndex].

{
	for (int index = endIndex;
		index > startIndex; index--)
		if (values[index] < values[index - 1])
			Swap(values[index], values[index - 1]);
}

template<typename ItemType>
void BubbleSort(ItemType values[], int numValues)
{
	int current = 0;
	while (current < numValues - 1)
	{
		BubbleUp(values, current, numValues - 1);
		current++;
	}
}


int main()
{
	string words[] = { "Cat", "Dog", "Rat", "House", "Lion", "Mouse", "Kode", "Safari", "Windows", "Apple" };
	
	BubbleSort(words, 10);
	for (int i = 0; i < 10; i++)
		cout << words[i] << " ";
	cout << endl;

	system("pause");

	return 0;
}

/*
Output

Apple Cat Dog House Kode Lion Mouse Rat Safari Windows
Press any key to continue . . .

*/


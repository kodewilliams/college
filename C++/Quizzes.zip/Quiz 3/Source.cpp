#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class flightType
{
public:
	string fromCity;
	string toCity;
	int maxPassengers;
	int currentPassengers;

};

class econoflightType : public flightType
{
public:
	float discountPrice;
	econoflightType();
};

struct nodeType
{
	econoflightType info;
	nodeType* next;
};

econoflightType::econoflightType()
{
	fromCity = "";
	toCity = "";
	maxPassengers = 0;
	currentPassengers = 0;
	discountPrice = 0.0;
}

void getFlightData(nodeType*& flightListptr, ifstream& dataFile);
void addEnd(nodeType flightNode, nodeType*& flightListptr);
void bookPassengers(nodeType* flightListptr, int no_of_Passengers, int flightNo);
void printBookingReport(nodeType* flightListptr);

int main()
{
	nodeType* flightListptr = NULL;
	ifstream dataFile;
	int flightNo, no_of_Passengers;
	dataFile.open("infile.txt");
	getFlightData(flightListptr, dataFile);
	printBookingReport(flightListptr);

	do
	{
		cout << endl << "Flight No (0-9): ";
		cin >> flightNo;
		cout << "No of New Passengers: ";
		cin >> no_of_Passengers;
		bookPassengers(flightListptr, no_of_Passengers, flightNo);
	} while (flightNo != 0 && no_of_Passengers != 0);

	printBookingReport(flightListptr);

	return 0;
}
void getFlightData(nodeType*& flightListptr, ifstream& dataFile)
{
	nodeType flightNode;
	for (int i = 0; i < 10; i++)
	{
		dataFile >> flightNode.info.fromCity
				>> flightNode.info.toCity
				>> flightNode.info.maxPassengers
				>> flightNode.info.currentPassengers
				>> flightNode.info.discountPrice;
		addEnd(flightNode, flightListptr);
	}
}
void addEnd(nodeType flightNode, nodeType*& flightListptr)
{
	if (flightListptr == NULL)
	{
		flightListptr = new nodeType;
		flightListptr->info.fromCity = flightNode.info.fromCity;
		flightListptr->info.toCity = flightNode.info.toCity;
		flightListptr->info.currentPassengers = flightNode.info.currentPassengers;
		flightListptr->info.maxPassengers = flightNode.info.maxPassengers;
		flightListptr->info.discountPrice = flightNode.info.discountPrice;
		flightListptr->next = NULL;
		/*
		flightListptr->info = flightNode.info;
		flightListptr->next = new nodeType;
		*/
		return;
	}
	else
	{
		nodeType* currentNode;
		for (currentNode = flightListptr; currentNode->next != NULL; currentNode = currentNode->next);
		currentNode->next = new nodeType;
		currentNode->next->info.fromCity = flightNode.info.fromCity;
		currentNode->next->info.toCity = flightNode.info.toCity;
		currentNode->next->info.currentPassengers = flightNode.info.currentPassengers;
		currentNode->next->info.maxPassengers = flightNode.info.maxPassengers;
		currentNode->next->info.discountPrice = flightNode.info.discountPrice;
		currentNode->next->next = NULL;

		/*
		currentNode->info = flightNode.info;
		currentNode->next = NULL;
		*/
	}
}

void bookPassengers(nodeType* flightListptr, int no_of_Passengers,
	int flightNo)
{
	nodeType* current = flightListptr;
	for (int x = 0; x < flightNo; x++)
	{
		current = current->next;
	}
	current->info.currentPassengers = no_of_Passengers;
}

void printBookingReport(nodeType* flightListptr)
{
	cout << fixed << showpoint;
	cout << "\n     From          To             Max       Current          Price\n\n";
	for (int x = 0; x < 10; x++)
	{
		cout << setw(12) << flightListptr->info.fromCity
			<< setw(12) << flightListptr->info.toCity
			<< setw(12) << flightListptr->info.maxPassengers
			<< setw(12) << flightListptr->info.currentPassengers
			<< setw(12) << setprecision(2) << "$" <<
			flightListptr->info.discountPrice << endl;
		flightListptr = flightListptr->next;
	}
}

/*

Output

From          To             Max       Current          Price

Washington    Richmond          35          34           $234.60
Huston     Chicago          50          48           $780.00
Newark      Denver          40          39           $657.25
Baltimore      Austin          25          20           $80.00
Richmond      Denver          35          33           $125.30
Washington      Austin          40          39           $259.10
Denver    Richmond          70          69           $345.12
Cleveland   Baltimore          20          18           $400.50
Chicago  Washington          20          19           $301.90
Huston   Cleveland          40          40           $712.95

Flight No (0-9): 1
No of New Passengers: 1

Flight No (0-9): 0
No of New Passengers: 0

From          To             Max       Current          Price

Washington    Richmond          35           0           $234.60
Huston     Chicago          50           1           $780.00
Newark      Denver          40          39           $657.25
Baltimore      Austin          25          20           $80.00
Richmond      Denver          35          33           $125.30
Washington      Austin          40          39           $259.10
Denver    Richmond          70          69           $345.12
Cleveland   Baltimore          20          18           $400.50
Chicago  Washington          20          19           $301.90
Huston   Cleveland          40          40           $712.95
Press any key to continue . . .

*/
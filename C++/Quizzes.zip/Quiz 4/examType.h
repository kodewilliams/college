/*Define an examType struct to store the data for each final exam. Each instance of this user-define type should contain the semester_name, the semester_year, the no_of _grades, the average_grade, the no_of_grades_above_average,  no_of_grades_below_average and a grades_array of 35 integers that will store up to 35 student grades for the semester final exam. (See data file above)
*/
struct ExamType // declaration of a struct
{
	std::string semester_name;
	int semester_year;
	int num_of_grades;
	int grades_array[35];
	float average_grade;
	int number_of_grades_above_average;
	int number_of_grades_below_average;
};

struct nodeType
{
	ExamType info;
	nodeType* next;
};
#include <iostream>
#include <string>
using namespace std;

class BinarySearchTree
{
private:
	struct TreeNode
	{
		string value;
		TreeNode *left;
		TreeNode *right;

		TreeNode(string value, TreeNode *left = NULL, TreeNode *right = NULL)
		{
			this->value = value;
			this->left = left;
			this->right = right;
		}
	};

	TreeNode *root;

	void insert(TreeNode *&tree, string value)
	{
		//if tree is empty
		if (tree == NULL)
		{
			tree = new TreeNode(value);
			return;
		}

		//if value is already in tree
		if (value == tree->value)
		{
			return;
		}

		if (value < tree->value)
			insert(tree->left, value);
		else
			insert(tree->right, value);
	}

	void displayInOrder(TreeNode *tree)
	{
		if (tree == NULL)
		{
			return;
		}
		else
		{
			displayInOrder(tree->left);
			cout << tree->value << " ";
			displayInOrder(tree->right);
		}
	}

public:
	BinarySearchTree()
	{
		root = NULL;
	}

	void insert(string value)
	{
		insert(root, value);
	}

	void showInOrder()
	{
		displayInOrder(root);
	}
};

int main()
{
	BinarySearchTree tree;

	tree.insert("P");
	tree.insert("R");
	tree.insert("O");
	tree.insert("T");
	tree.insert("O");
	tree.insert("C");
	tree.insert("O");
	tree.insert("L");

	tree.showInOrder();

	return 0;
}

/*
Output

C L O P R T Press any key to continue . . .
*/